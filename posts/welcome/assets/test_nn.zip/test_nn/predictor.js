let handpose;
let video;
let predictions = [];
let myNeuralNetwork;
let label = "Detecting...";
let currentConfidence = 0;
let currentSoundLabel = "None";
let sounds = {};
let lastLabel = "";


let mudraToSound = {
  arala: 'chalamela.mp3',  
  mayura: 'jalajakshi.mp3',
  kataka_mukha: 'ninnukori.mp3',
  kapita: 'swamiDayaChuda.mp3',
  kartari: 'vanajakshi.mp3'
};

function preload() {
  for (let mudra in mudraToSound) {
    sounds[mudra] = loadSound(`sounds/${mudraToSound[mudra]}`);
  }
}

function setup() {
  createCanvas(640, 480);
  video = createCapture(VIDEO);
  video.size(width, height);
  video.hide();

  handpose = ml5.handpose(video, () => {
    console.log("Handpose ready");
  });

  handpose.on("predict", (results) => {
    predictions = results;
  });

  const options = {
    inputs: 42,
    outputs: ["label"],
    task: 'classification',
    debug: true
  };

  myNeuralNetwork = ml5.neuralNetwork(options);
  myNeuralNetwork.load('model.json', modelLoaded);
}

function modelLoaded() {
  console.log("Mudra model loaded");
}

function draw() {


  image(video, 0, 0, width, height);

  if (predictions.length > 0) {
    let landmarks = predictions[0].landmarks;
    let inputs = [];

    for (let pt of landmarks) {
      inputs.push(pt[0]);
      inputs.push(pt[1]);
    }

    if (inputs.length === 42) {
      myNeuralNetwork.classify(inputs, gotResult);
    }

    // Draw hand keypoints
    fill(0, 255, 0);
    noStroke();
    for (let pt of landmarks) {
      ellipse(pt[0], pt[1], 10, 10);
    }
  } else {
    //No hand detected — stop everything
    label = "None";
    currentConfidence = 0;
    currentSoundLabel = "None";

    // Stop any playing sound
    for (let mudra in sounds) {
      if (sounds[mudra].isPlaying()) {
        sounds[mudra].stop();
      }
    }

    lastLabel = ""; // reset last label so it can trigger again next time
  }

  // Display info
  fill(255);
  textSize(28);
  text(`Mudra: ${label}`, 10, height - 40);
  text(`Confidence: ${nf(currentConfidence, 1, 2)}`, 10, height - 10);

  fill('#ff69b4');
  textSize(20);
  text(`Playing: ${currentSoundLabel}`, 10, 30);
}


function gotResult(err, results) {
  if (err) {
    console.error(err);
    return;
  }

  if (results && results[0]) {
    const confidence = results[0].confidence;
    const predictedLabel = results[0].label;

    currentConfidence = confidence;

    // If mudra changed
    if (predictedLabel !== lastLabel) {
      // Stop all sounds
      for (let mudra in sounds) {
        if (sounds[mudra].isPlaying()) {
          sounds[mudra].stop();
        }
      }

      // Play new mudra sound
      if (sounds[predictedLabel]) {
        sounds[predictedLabel].play();
        currentSoundLabel = mudraToSound[predictedLabel].replace('.mp3', '');
      } else {
        currentSoundLabel = "None";
      }

      lastLabel = predictedLabel;
    }

    label = predictedLabel;
    document.getElementById("prediction").textContent = `Mudra: ${label}`;
  }
}
let myNeuralNetwork;

function setup() {
  noCanvas();

  const options = {
    dataUrl: 'final_mudra_dataset.csv',
    inputs: [
      "wrist_x", "wrist_y",
      "thumb_cmc_x", "thumb_cmc_y",
      "thumb_mcp_x", "thumb_mcp_y",
      "thumb_ip_x", "thumb_ip_y",
      "thumb_tip_x", "thumb_tip_y",
      "index_finger_mcp_x", "index_finger_mcp_y",
      "index_finger_pip_x", "index_finger_pip_y",
      "index_finger_dip_x", "index_finger_dip_y",
      "index_finger_tip_x", "index_finger_tip_y",
      "middle_finger_mcp_x", "middle_finger_mcp_y",
      "middle_finger_pip_x", "middle_finger_pip_y",
      "middle_finger_dip_x", "middle_finger_dip_y",
      "middle_finger_tip_x", "middle_finger_tip_y",
      "ring_finger_mcp_x", "ring_finger_mcp_y",
      "ring_finger_pip_x", "ring_finger_pip_y",
      "ring_finger_dip_x", "ring_finger_dip_y",
      "ring_finger_tip_x", "ring_finger_tip_y",
      "pinky_finger_mcp_x", "pinky_finger_mcp_y",
      "pinky_finger_pip_x", "pinky_finger_pip_y",
      "pinky_finger_dip_x", "pinky_finger_dip_y",
      "pinky_finger_tip_x", "pinky_finger_tip_y"
    ],
    outputs: ['mudra_name'], // or use 'label' if your CSV uses that
    task: 'classification',
    debug: true
  };

  myNeuralNetwork = ml5.neuralNetwork(options, dataLoaded);
}

function dataLoaded() {
  console.log("Data loaded, starting training...");
  myNeuralNetwork.normalizeData();
  myNeuralNetwork.train({ epochs: 100 }, finishedTraining);
}

function finishedTraining() {
  console.log("Training complete!");
  myNeuralNetwork.save(); // triggers model.json + weights download
}






